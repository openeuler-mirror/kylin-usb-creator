# USB Boot Maker

## Overview
<br>
       USB Boot Maker is a self-developed tool for the production system to start the U Disk, can be made into a u disk form of the installation media, easy to no optical drive media computer installation mirror files.
<br>

## Open mode
<br>

  **"Start Menu">"U Disk launcher"**or**"Taskbar">"Search">"U Disk launcher"**.
<br>

## Basic operation
<br>

  Open U Disk launcher, click**"Browse"**,select the local CD image file, insert U Disk and choose to make a boot disk u disk.
<br>

![](image/image1.png)

<br>

  Select a good mirror file and U Disk, Click**"Start production"**,will pop-up authorization window, enter the user password, click**"Authorization"**,waiting for the completion of production.
<br>

![](image/image2.png)

<br>
When you’re done, you’ll be prompted.
 <br>

![](image/image3.png)