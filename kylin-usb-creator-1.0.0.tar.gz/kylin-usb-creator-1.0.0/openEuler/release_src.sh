#!/bin/bash

pkg_name=kylin-usb-creator

pwd
cp $pkg_name.spec ../../../src_house/$pkg_name-fork/
cp *.tar.* ../../../src_house/$pkg_name-fork/
