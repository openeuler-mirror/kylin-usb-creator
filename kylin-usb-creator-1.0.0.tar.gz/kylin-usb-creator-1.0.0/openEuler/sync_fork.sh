# git remote add upstream https://github.com/UbuntuKylin/kylin-calculator.git
git fetch upstream
git checkout master
git merge upstream/master
git push