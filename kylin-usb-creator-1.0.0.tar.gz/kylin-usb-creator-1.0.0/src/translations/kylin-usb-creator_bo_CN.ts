<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="16"/>
        <location filename="../mainwindow.cpp" line="120"/>
        <source>kylin usb creator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page1</name>
    <message>
        <location filename="../page1.cpp" line="43"/>
        <source>choose iso file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="90"/>
        <source>USB drive will be formatted,please backup your files!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="167"/>
        <source>Authorization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="146"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="20"/>
        <source>Choose iso file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="21"/>
        <source>Select USB drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="40"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="48"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="209"/>
        <source>These operations needs to be verified:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="142"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="211"/>
        <source>Request authorization:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="214"/>
        <source>Password：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="308"/>
        <source>No USB drive available</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page2</name>
    <message>
        <location filename="../page2.cpp" line="69"/>
        <source>USB starter in production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="76"/>
        <source>Please do not remove the USB driver or power off now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="86"/>
        <location filename="../page2.cpp" line="102"/>
        <source>return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="90"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="106"/>
        <source>Creation Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StyleWidget</name>
    <message>
        <location filename="../stylewidget.cpp" line="7"/>
        <source>kylin usb creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stylewidget.cpp" line="146"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stylewidget.cpp" line="148"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stylewidget.cpp" line="150"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stylewidget.cpp" line="152"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rootAuthDialog</name>
    <message>
        <location filename="../rootauthdialog.cpp" line="13"/>
        <source>Input password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rootauthdialog.cpp" line="49"/>
        <source>please enter the password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rootauthdialog.cpp" line="66"/>
        <source>Wrong password!Try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rootauthdialog.cpp" line="74"/>
        <source>Current user is not in the sudoers file,please change another account or change authority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
