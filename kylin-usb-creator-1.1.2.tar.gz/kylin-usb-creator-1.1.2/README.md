# Kylin-USB-Creator

一款U盘启动盘制作工具

## 更新日志

1.0.0-12kord kylin-usb-creator

- 文件对话框汉化
- 修改重复制作时root授权提示密码错误
- root密码校验功能解耦
- U盘选择框文字像素遮挡
- 高分屏适配
- VNC适配
- 任务失败处理逻辑完善
- U盘下拉列表框宽度修改

1.0.0-13kord kylin-usb-creator

- 修复了暗黑主题下文字颜色演示异常的问题
- 增加了U盘框预选的功能。当有U盘插入时可以自动选中
