/*
 * Copyright (C) 2002  KylinSoft Co., Ltd.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef SYSTEMDBUSREGISTER_H
#define SYSTEMDBUSREGISTER_H

#include <QtDBus/QDBusContext>
#include <QObject>
#include <QCoreApplication>
#include <QProcess>
#include <QFile>
#include <QSettings>
#include <QFileInfo>
#include <QProcess>
#include <QTimer>
#include <QStorageInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonArray>

class SystemDbusRegister : public QObject, protected QDBusContext
{
    Q_OBJECT
//    Q_CLASSINFO("D-Bus Interface", "com.kylinusbcreator.interface")
    Q_CLASSINFO("D-Bus Interface", "com.kylinusbcreator.interface")
public:
    SystemDbusRegister();
//    ~SystemDbusRegister();

Q_SIGNALS:
    void workingProgress(int);
    void makeFinish(QString);
    void authorityStatus(QString);

public slots:
    Q_SCRIPTABLE void MakeStart(QString sourcePath,QString targetPath);
    Q_SCRIPTABLE void MakeExit();
private:
    void readBashStandardErrorInfo();
    void finishEvent();
    bool unmountDevice(QString);
    bool isMakingSucess();

private:
    QString uDiskPath = "";
    qint64 sourceFileSize = 0;
    QProcess *command_dd = nullptr;
    QJsonArray QStringToJsonArray(const QString);

};

#endif // SYSTEMDBUSREGISTER_H
