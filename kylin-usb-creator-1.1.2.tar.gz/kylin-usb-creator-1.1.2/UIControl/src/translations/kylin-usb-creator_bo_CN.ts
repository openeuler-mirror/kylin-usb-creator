<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="32"/>
        <location filename="../mainwindow.cpp" line="91"/>
        <location filename="../mainwindow.cpp" line="182"/>
        <source>usb boot maker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="34"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="50"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>USB driver is in production.Are you sure you want to stop task and exit the program?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page1</name>
    <message>
        <location filename="../page1.cpp" line="35"/>
        <source>choose iso file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="38"/>
        <source>MBR signature not detected,continue anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="114"/>
        <source>USB drive will be formatted,please backup your files!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="15"/>
        <source>Choose iso file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="16"/>
        <source>Select USB drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="32"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="38"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="64"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page1.cpp" line="291"/>
        <source>No USB drive available</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page2</name>
    <message>
        <location filename="../page2.cpp" line="75"/>
        <source>USB starter in production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="87"/>
        <source>Please do not remove the USB driver or power off now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="94"/>
        <location filename="../page2.cpp" line="116"/>
        <source>return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="98"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../page2.cpp" line="121"/>
        <source>Creation Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../../../../../Qt5.12.8/5.12.8/clang_64/lib/QtWidgets.framework/Headers/qmessagebox.h" line="320"/>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../../Qt5.12.8/5.12.8/clang_64/lib/QtWidgets.framework/Headers/qmessagebox.h" line="322"/>
        <source>Incompatible Qt Library Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>T::QApplication</name>
    <message>
        <location filename="../../../../../Qt5.12.8/5.12.8/clang_64/lib/QtWidgets.framework/Headers/qmessagebox.h" line="320"/>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../../Qt5.12.8/5.12.8/clang_64/lib/QtWidgets.framework/Headers/qmessagebox.h" line="322"/>
        <source>Incompatible Qt Library Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <location filename="../include/menumodule.cpp" line="21"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="33"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="35"/>
        <location filename="../include/menumodule.cpp" line="114"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="37"/>
        <location filename="../include/menumodule.cpp" line="112"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="39"/>
        <location filename="../include/menumodule.cpp" line="110"/>
        <location filename="../include/menumodule.cpp" line="199"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="46"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="50"/>
        <location filename="../include/menumodule.cpp" line="125"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="54"/>
        <location filename="../include/menumodule.cpp" line="130"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="202"/>
        <location filename="../include/menumodule.cpp" line="229"/>
        <source>usb boot maker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="221"/>
        <source>USB Boot Maker provides system image making function.The operation process is simple and easy.You can choose ISO image and usb driver,and make boot driver with a few clicks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="232"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/menumodule.cpp" line="296"/>
        <location filename="../include/menumodule.cpp" line="305"/>
        <source>Service &amp; Support: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
